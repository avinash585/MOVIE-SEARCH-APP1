// src/components/Favorites.js
import React from 'react';

const Favorites = ({ favorites, onRemoveFromFavorites }) => {
  return (
    <div className="favorites">
      <h2>Favorites</h2>
      {favorites.length === 0 ? (
        <p>No favorites yet</p>
      ) : (
        favorites.map(movie => (
          <div key={movie.imdbID} className="favorite-movie">
            <img src={movie.Poster} alt={movie.Title} />
            <div className="favorite-info">
              <h3>{movie.Title}</h3>
              <button onClick={() => onRemoveFromFavorites(movie)}>Remove</button>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default Favorites;
