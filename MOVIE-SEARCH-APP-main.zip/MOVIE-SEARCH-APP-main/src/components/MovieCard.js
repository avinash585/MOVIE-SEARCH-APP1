// src/components/MovieCard.js
import React from 'react';

const MovieCard = ({ movie, onAddToFavorites }) => {
  return (
    <div className="movie-card">
      <img src={movie.Poster} alt={movie.Title} />
      <div className="movie-info">
        <h3>{movie.Title}</h3>
        <p>{movie.Year}</p>
        <button onClick={() => onAddToFavorites(movie)}>Add to Favorites</button>
      </div>
    </div>
  );
};

export default MovieCard;
