// src/App.js
import React, { useState } from 'react';
import axios from 'axios';
import SearchForm from './components/SearchForm';
import MovieList from './components/MovieList';
import Favorites from './components/Favorites';
import './App.css'; // Optional for custom styles

const App = () => {
  const [movies, setMovies] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [error, setError] = useState(null);

  const apiKey = '5b03d2fd'; // OMDB API key

  // Fetch movies from the OMDB API based on user input
  const searchMovies = async (query) => {
    try {
      const response = await axios.get(`https://www.omdbapi.com/?s=${query}&apikey=${apiKey}`);
      if (response.data.Response === 'True') {
        setMovies(response.data.Search);
        setError(null);
      } else {
        setError('No movies found');
        setMovies([]);
      }
    } catch (err) {
      setError('Error fetching data');
      setMovies([]);
    }
  };

  // Add movie to favorites
  const addToFavorites = (movie) => {
    if (!favorites.includes(movie)) {
      setFavorites([...favorites, movie]);
    }
  };

  // Remove movie from favorites
  const removeFromFavorites = (movie) => {
    setFavorites(favorites.filter(fav => fav.imdbID !== movie.imdbID));
  };

  return (
    <div className="app-container">
      <h1>Movie Search App</h1>
      <SearchForm onSearch={searchMovies} />
      {error && <p className="error">{error}</p>}
      <MovieList movies={movies} onAddToFavorites={addToFavorites} />
      <Favorites favorites={favorites} onRemoveFromFavorites={removeFromFavorites} />
    </div>
  );
};

export default App;
